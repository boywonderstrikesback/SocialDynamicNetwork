import { NgModule } from '@angular/core';

import { DynamicSocialNetworkSharedLibsModule, JhiAlertComponent, JhiAlertErrorComponent } from './';

@NgModule({
    imports: [DynamicSocialNetworkSharedLibsModule],
    declarations: [JhiAlertComponent, JhiAlertErrorComponent],
    exports: [DynamicSocialNetworkSharedLibsModule, JhiAlertComponent, JhiAlertErrorComponent]
})
export class DynamicSocialNetworkSharedCommonModule {}
