import { IPost } from 'app/shared/model//post.model';

export interface IOwner {
    id?: number;
    name?: string;
    posts?: IPost[];
}

export class Owner implements IOwner {
    constructor(public id?: number, public name?: string, public posts?: IPost[]) {}
}
