import { IOwner } from 'app/shared/model//owner.model';

export interface IPost {
    id?: number;
    title?: string;
    text?: string;
    imageUrl?: string;
    owner?: IOwner;
}

export class Post implements IPost {
    constructor(public id?: number, public title?: string, public text?: string, public imageUrl?: string, public owner?: IOwner) {}
}
