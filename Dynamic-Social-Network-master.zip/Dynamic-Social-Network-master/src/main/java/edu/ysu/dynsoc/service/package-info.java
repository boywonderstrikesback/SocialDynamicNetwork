/**
 * Service layer beans.
 */
package edu.ysu.dynsoc.service;
