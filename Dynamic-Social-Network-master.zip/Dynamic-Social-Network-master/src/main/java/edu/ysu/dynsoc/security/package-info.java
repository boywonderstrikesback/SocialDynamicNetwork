/**
 * Spring Security configuration.
 */
package edu.ysu.dynsoc.security;
