/**
 * Data Transfer Objects.
 */
package edu.ysu.dynsoc.service.dto;
