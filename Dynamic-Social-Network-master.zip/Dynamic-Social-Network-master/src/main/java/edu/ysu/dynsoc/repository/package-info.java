/**
 * Spring Data JPA repositories.
 */
package edu.ysu.dynsoc.repository;
