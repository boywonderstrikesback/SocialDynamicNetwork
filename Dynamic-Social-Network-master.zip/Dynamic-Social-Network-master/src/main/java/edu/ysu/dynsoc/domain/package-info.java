/**
 * JPA domain objects.
 */
package edu.ysu.dynsoc.domain;
